﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CABLE_OPERATIONS.Entities
{
    public class Customer_Dashboard
    {
    public    string name { get; set; }
     public   string package_name { get; set; }

    }
}
